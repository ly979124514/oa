<template>
 <f7-page navbar-fixed>
  <f7-navbar back-link="Back" title="工作流程" sliding></f7-navbar>
  <h1>WorkFlow Content</h1>
  <h1>开发...........</h1>
 </f7-page>
</template>
