<template>
   <f7-page>
    <f7-navbar back-link="Back" title="草稿箱" sliding></f7-navbar>
    <p>This is Draf</p>
   </f7-page>
</template>
