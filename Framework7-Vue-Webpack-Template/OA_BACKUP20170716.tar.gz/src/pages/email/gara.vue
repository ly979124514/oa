<template>
   <f7-page>
    <f7-navbar back-link="Back" title="垃圾箱" sliding></f7-navbar>
    <p>This is Garage</p>
   </f7-page>
</template>
