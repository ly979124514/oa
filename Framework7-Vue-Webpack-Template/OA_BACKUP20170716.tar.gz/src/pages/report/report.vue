<template>
 <f7-page navbar-fixed>
  <f7-navbar back-link="Back" title="报告" sliding></f7-navbar>
  <h1>Report Content</h1>
  <h1>开发。。。。。</h1>
 </f7-page>
</template>
