<template>
 <f7-page>
  <p>Tab 2 Content</p>
 </f7-page>
</template>
