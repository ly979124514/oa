<template>
 <f7-page name="grid">    
   <f7-grid>
      <f7-col>col 1</f7-col>
      <f7-col>col2</f7-col>
      <f7-col>col 3</f7-col>
      <f7-col>col 4</f7-col>
    </f7-grid>
  </f7-page>
</template>
