<template>
 <f7-page>
  <p>Tab 3 Content</p>
 </f7-page>
</template>
