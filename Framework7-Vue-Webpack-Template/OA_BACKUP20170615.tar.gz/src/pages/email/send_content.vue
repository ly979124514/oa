<template>
  <f7-page @page:init="pageInit">
   <f7-navbar back-link="Back" title="写邮件" sliding></f7-navbar>
   <f7-list form>
     <f7-list-item>
       <f7-label>收件人</f7-label>
       <f7-input id="recieverLabel" type="text" v-model="reciever"/>
     </f7-list-item>
     <f7-list-item>
       <f7-label>时间</f7-label>
       <f7-input ref="date_input" v-model="date" type="text" disabled="true"/>
     </f7-list-item>
     <f7-list-item>
       <f7-label>标题</f7-label>
       <f7-input type="text" v-model="title"/>
     </f7-list-item>
     <f7-list-item>
       <f7-label>内容</f7-label>
       <f7-input type="textarea" v-model="content"/>
     </f7-list-item>
     <f7-list-item>
        <f7-button @click="sendMessage">发送</f7-button><f7-button>返回</f7-button>
     </f7-list-item>
   </f7-list>
  </f7-page>
</template>
<script>
export default {
  data () {
    return {
      myDate : new Date(),
      apiUri:'http://172.31.0.31:8081/cat/sendMail',
      jsonMail:{"emailContent":"","emailReciever":"","emailSender":"ly979124514@163.com","emailDate":"","emailTitle":""},
      json2String:'',
    }
  },
  methods : {
    sendMessage: function(){
        console.log(this.title);
        console.log(this.reciever);
        console.log(this.mydate);
        console.log(this.content);
        this.jsonMail.emailContent=this.content;
        this.jsonMail.emailReciever=this.reciever;
        this.jsonMail.emailDate=this.get_timp();
        this.jsonMail.emailTitle=this.title;
        this.json2String=JSON.stringify(this.jsonMail);
        console.log('json2String:'+ this.json2String);
        this.$http.post(this.apiUri,this.json2String).then(function (response){})
    },
   get_timp: function (){
        var myDate = new Date();
        var timp = myDate.getFullYear()+'-'+myDate.getMonth()+'-'+myDate.getDate()+' '+myDate.getHours()+':'+myDate.getMinutes()+':'+myDate.getSeconds();
        console.log(timp);
        return timp;
   },
   pageInit: function() {
        this.$refs.date_input.value=this.get_timp();
   }
  }
}
</script>
