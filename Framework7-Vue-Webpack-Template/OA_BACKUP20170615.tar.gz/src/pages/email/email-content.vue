<template>
  <f7-page navbar-fixed>
      <f7-navbar back-link="Back" title="邮箱" sliding></f7-navbar>
         <f7-block tabs>
           <f7-tab route-tab-id="tabReci" />
           <f7-tab route-tab-id="tabSend" />
           <f7-tab route-tab-id="tabGara" />
           <f7-tab route-tab-id="tabDraf" />
         </f7-block>
         <f7-toolbar tabbar labels>
           <f7-link href="/reci" text="收件箱"></f7-link>
           <f7-link href="/send" text="发件箱"></f7-link>
           <f7-link href="/gara" text="垃圾箱"></f7-link>
           <f7-link href="/draf" text="草稿箱"></f7-link>
           <f7-link @click="$router.load({url: '/content/'})" text="测试"></f7-link>
         </f7-toolbar>
   </f7-page>
 </f7-pages>
</template>
