<template>
 <f7-page navbar-fixed>
  <f7-navbar back-link="Back" title="日程" sliding></f7-navbar>
  <f7-timeline horizontal col="33" tablet-col="15">
     <f7-timeline-year title="2017">
       <f7-timeline-month title="六月">
          <f7-timeline-item date="周一">9:00 开会</f7-timeline-item>
          <f7-timeline-item date="周二">开会</f7-timeline-item>
          <f7-timeline-item date="周三">开会</f7-timeline-item>
          <f7-timeline-item date="周四">开会</f7-timeline-item>
          <f7-timeline-item date="周五">开会</f7-timeline-item>
          <f7-timeline-item date="周六">开会</f7-timeline-item>
          <f7-timeline-item date="周日">开会</f7-timeline-item>
      </f7-timeline-month>
    </f7-timeline-year>
  </f7-timeline>
 </f7-page>
</template>
