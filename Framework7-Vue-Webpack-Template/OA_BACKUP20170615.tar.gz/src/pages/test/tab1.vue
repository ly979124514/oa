<template>
 <f7-page>
  <p>Tab 1 Content</p>
 </f7-page>
</template>
