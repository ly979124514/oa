import * as types from '../mutation-types'
const state = {
   logOn: false,
   HttpServer: null
}

const getters = {
   logOn: state => state.logOn,
   HttpServer: state => state.HttpServer
}

const actions = {
  checkout ({ commit }) {
      commit(types.FRESH_LOGSTATE)
  },
  getHttpServer ({ commit }, httpServer ) {
      commit(types.CONNECT_SERVER, httpServer)
  } 
}

const mutations = {
     [types.FRESH_LOGSTATE] (state) {
        state.logOn = true
     },
     [types.CONNECT_SERVER] (state, httpServer) {
        state.HttpServer = httpServer
     }
}

export default {
  state,
  actions,
  getters,
  mutations
}

